do

function run(msg, matches)
  return [[
#Sudoers!
  
  1.@@Mohammad_NBG 🌐 #Developer 
  
  2.@kiava_ir 🌐 #Manager & #Developer 
  
]]
end
return {
  description = " ", 
  usage = " ",
  patterns = {
    "^[#!/]sudoers$",

  },
  run = run
}
end

--designed by kiava.ir
