do


function run(msg, matches)

  return [[خرید آنلاین گروه با ربات کیاوا🚀
جهت خرید گروه 1 ماهه کافیست⏬
/by_10
را ارسال کنید
💰💰💰💰💰💰💰💰
جهت خرید گروه 1 ساله کافیست⏬
/by_30
را ارسال کنید
💰💰💰💰💰💰💰💰
جهت خرید گروه نامحدود⏬
/by_35
را ارسال کنید
💰💰💰💰💰💰💰💰]]

end


return {

  description = "", 

  usage = "",

  patterns = {

    "^[/!#]kharid_group$"

  }, 

  run = run 

}


end
